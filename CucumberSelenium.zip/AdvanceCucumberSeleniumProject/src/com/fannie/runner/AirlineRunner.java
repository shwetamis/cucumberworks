package com.fannie.runner;


	import org.junit.runner.RunWith;

	import cucumber.api.CucumberOptions;
	import cucumber.api.junit.Cucumber;

	@RunWith(Cucumber.class)
	@CucumberOptions(    
			features={"src/com/fannie/feature"},
			plugin={"pretty","html:target/cucumber-html-report"},
			glue={"com.fannie.step","com.fannie.utilities"},
				monochrome=true
				//dryRun=true
			//tags={"@Sanity"} // this will not execute sanity but every other feature {"~@Sanity"}
			//tags={"~@Sanity"}
			
			//regular expression for running many features except for one
			)

	public class AirlineRunner {

		
	}


