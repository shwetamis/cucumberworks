package com.fannie.step;

import org.openqa.selenium.WebDriver;

import com.fannie.pom.FlightPagePOMFactory;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AirlineStep {
WebDriver driver;
private FlightPagePOMFactory factory;

@Given("^Chrome Browser$")
public void chrome_Browser() throws Throwable {
driver =com.fannie.pom.DriverFactory.getDriver("chrome");
//System.out.println("Browser is chrome");
	}
@When("airline pom")
public void airline_pom(){
	factory= new FlightPagePOMFactory(driver);
	driver.get("http://expedia.com");
}


@Given("^click on flights tab$")
public void click_on_flights_tab() throws Throwable {
	 System.out.println("Flight tab clicked");
	// driver.get("https://www.expedia.com");
	 factory.clickFlightTab();
	 
}

@Given("^enter \"([^\"]*)\" the src location$")
public void enter_the_src_location(String arg1) throws Throwable {
    factory.sendFlyingFrom(arg1);
 
}

@Given("^enter \"([^\"]*)\" the dest location$")
public void enter_the_dest_location(String arg1) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	factory.sendFlyingTo(arg1);
}

@Given("^enter departure \"([^\"]*)\"$")
public void enter_departure(String arg1) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
  factory.sendDepartingDate(arg1);
}

@Given("^enter return \"([^\"]*)\"$")
public void enter_return(String arg1) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	factory.sendReturnDate(arg1);
}

@When("^click on search button$")
public void click_on_search_button() throws Throwable {
 factory.clickSearchBtn();
  
}

@Then("^show the flight information$")
public void show_the_flight_information() throws Throwable {
	
	System.out.println("Then show the flight info");
 
}


}
