package com.fannie.pom;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class DriverFactory {
	static WebDriver driver;
	public static WebDriver getDriver( String browser){
		
		if(browser.equals("chrome")){	
			System.out.println("loading chrome driver... ");
			System.setProperty("webdriver.chrome.driver", "C:\\selenium\\chrome\\chromedriver_win32\\chromedriver.exe");// this is the location where your driver is
		    driver = new ChromeDriver();
		    driver.manage().window().maximize();
		    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);//wait for 30 secs, if this is commented out the test fails as after login email page won't stay

		    return driver;
		} else if (browser.equals("ie")){
			
		}else if (browser.equals("firefox")){
			
		}
		return null;
	}
	
	
}
