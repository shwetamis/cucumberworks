package com.test.runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(    
		features={"feature/com/fannie"},
		format={"pretty","html:target/cucumber-html-report"},
		glue={"com.fannie.step"},
			monochrome=true,
			//dryRun=true
		tags={"@Sanity"} // this will not execute sanity but every other feature {"~@Sanity"}
		//tags={"~@Sanity"}
		
		//regular expression for running many features except for one
		)

public class TestRunner {

	
}
