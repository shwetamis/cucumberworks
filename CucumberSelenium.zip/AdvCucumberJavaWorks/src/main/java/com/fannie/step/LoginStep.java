package com.fannie.step;

import java.util.List;
import java.util.Map;

import cucumber.api.DataTable;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStep {
	
	//this method will be global for teh application
	@Before
	public void hookMethod(){
		System.out.println("***** Hey you have to connect to Db");
	}
/*	@Given("Launch FireFox:")
	public void setup(){
		System.out.println("*********** Launching Firefox Browser*************");
	}
	*/
	 @Before("@FirstDryRun") 
	public void betaTestCases(){
		 System.out.println("####################Connect to some server#############");
	 }
	@Given("^Launch Firebox$")
	public void launch_Firebox() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("*********** Launching Firefox Browser*************");
	}

	@When("^user successfully logs in$")
	public void user_successfully_logs_in(DataTable data) throws Throwable {
		System.out.println("user successfully logged  in");
		List<Map<String, String>> list = data.asMaps(String.class, String.class);
		// for each entry of map in the list
		for(Map<String, String> temp :list){
System.out.print("Login-->"+ temp.get("login"));
System.out.println("Password-->"+ temp.get("password"));

		}

	    
	}

	@Then("^show inbox$")
	public void show_inbox() throws Throwable {
		System.out.println("show inbox");
	
	}

}
