package com.fannie.step;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStep {
	@When("^user successfully logs in$")
	public void user_successfully_logs_in() throws Throwable {
System.out.println("user successfully lohn in");
	    
	}

	@Then("^show inbox$")
	public void show_inbox() throws Throwable {
		System.out.println("show inbox");
	
	}

}
