package com.fannie.step;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CreditScoreStep {
	//Glue code

	@Given("^Employee has a credit score of required$")
	public void employee_has_a_credit_score_of_required() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	 System.out.println("Employee has credit score of ");
	}

	@Given("^according to bank standard$")
	public void according_to_bank_standard() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("according to bank standard ");
	}

	@When("^customer has \"([a-zA-Z]{1,})\" time work$") //// \"(a-zA-Z]{1,})\"--> this regular expression looks into feature file and search text within the quotes
	// if you put : + it can take any characters rather than one word \"(a-zA-Z]{1,+})\"
	public void customer_has_full_time_work(String work) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("customer has " + work + "time work...");
	}

	@When("^in \"([a-zA-Z]{1,})\" office$")
	public void in_govt_office(String office) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("In " + office + "office...");
	}

	@Then("^Sanction loan$")
	public void sanction_loan() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Sanction loan");
	}

	@Then("^should be repay in \"([^\"]*)\" years$")
	public void should_be_repay_in_years(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
	}
//	@When("^in \"a-zA-Z]{1,}\"  office$")
//	public void in_private_office() throws Throwable {
//	    // Write code here that turns the phrase above into concrete actions
//		System.out.println("in private office ");
//	}
//
//	@Then("^should be repay in \"a-zA-Z]{1,}\"  years$")
//	public void should_be_repay_in_four_years() throws Throwable {
//	    // Write code here that turns the phrase above into concrete actions
//		System.out.println("should be repay in four year ");
//	}

}
